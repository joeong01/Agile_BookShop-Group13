<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <style>
        body {background-color: rgb(95, 220, 254)}
    </style>
    <title>Book Booking System</title>

</head>
<body>
    <?php echo e(View::make('userHeader')); ?>

    
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo e(View::make('footer')); ?>

</body>
</html><?php /**PATH D:\WebDesign\htdocs\BookBookingSystem\resources\views/userHomepage.blade.php ENDPATH**/ ?>