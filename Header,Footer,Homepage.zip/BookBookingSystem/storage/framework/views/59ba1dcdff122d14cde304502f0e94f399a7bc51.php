<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Book Bokking System-Admin</title>


</head>
<body style="background-color: gainsboro;">
    <?php echo e(View::make('adminHeader')); ?>

    

    <?php echo e(View::make('footer')); ?>

</body>
</html><?php /**PATH D:\WebDesign\htdocs\BookBookingSystem\resources\views/adminHomepage.blade.php ENDPATH**/ ?>